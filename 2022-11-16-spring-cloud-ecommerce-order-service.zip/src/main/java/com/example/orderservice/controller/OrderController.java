package com.example.orderservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderservice.dto.OrderDto;
import com.example.orderservice.jpa.OrderEntity;
import com.example.orderservice.messagequeue.KafkaProducer;
import com.example.orderservice.messagequeue.OrderProducer;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.vo.RequestOrder;
import com.example.orderservice.vo.ResponseOrder;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/order-service")
@Slf4j
public class OrderController {
    Environment env;
    OrderService orderService;
    KafkaProducer kafkaProducer;

    OrderProducer orderProducer;

    @Autowired
    public OrderController(Environment env, OrderService orderService,
                           KafkaProducer kafkaProducer, OrderProducer orderProducer) {
        this.env = env;
        this.orderService = orderService;
        this.kafkaProducer = kafkaProducer;
        this.orderProducer = orderProducer;
    }

    @GetMapping("/health_check")
    public String status() {
        return String.format("It's Working in Order Service on PORT %s",
                env.getProperty("local.server.port"));
    }

//    (post)http://127.0.0.1:8000/order-service/58637473-1c45-463e-8378-f9eb09cb279c/orders
    @PostMapping("/{userId}/orders")
    public ResponseEntity<ResponseOrder> createOrder(@PathVariable("userId") String userId,
                                                     @RequestBody RequestOrder orderDetails) {
        log.info("Before add orders data");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

        OrderDto orderDto = mapper.map(orderDetails, OrderDto.class);
        orderDto.setUserId(userId);
        /* jpa */
        OrderDto createdOrder = orderService.createOrder(orderDto);

        ResponseOrder responseOrder = mapper.map(createdOrder, ResponseOrder.class);

        /////////////////////////////////////////////////////////////////////////////////////
        // 기존에는 주문하면 주문을 하나 createOrder하는 것으로 끝났지만
        // 주문이 완료하기 위한 메시지 이벤트를 발생시켜
        // 주문 수량을 조정한다.
        /////////////////////////////////////////////////////////////////////////////////////

        /* send this order to the kafka */
        /*
         * 여기서 example-order-topic 을  pub하면 catalog-service에서 sub하는 방식이다.
         * 여기서는 메시징을 통해서 이벤트를 전달하는 방식이다.
         * 즉 컨슈머측에서 로직을 구사하는 방식이다.
         * 1번 2번을 동시에 하면 두번하는 방식이니 두개중 하나를 택한다.
         */
        T1 : 
        {        	
//        	kafkaProducer.send("example-order-topic", orderDto);
        }
        
        /*
         * 2번 스타일 
         * 여기서 example-order-topic 을  pub하면 sink-connector에서 sub하는 방식이다.
         * 여기서는 데이타베이스의 내용을 전달하는 방식이다.
         * 그럼 변경 내용을 여기서 변경하여 내용을 전달한다. 그래서 UUID 부분과 물량을 여기서 조정하여
         * 순수하게 데이타만으로 처리하는 방식을 말한다.
         */
        T2:
        {
        	orderDto.setOrderId(UUID.randomUUID().toString());
        	orderDto.setTotalPrice(orderDetails.getQty() * orderDetails.getUnitPrice());
        	kafkaProducer.send("example-catalog-topic", orderDto);
        	orderProducer.send("my_sink_orders", orderDto);
        }

        log.info("After added orders data");
        return ResponseEntity.status(HttpStatus.CREATED).body(responseOrder);
    }

    @GetMapping("/{userId}/orders")
    public ResponseEntity<List<ResponseOrder>> getOrder(@PathVariable("userId") String userId) throws Exception {
        log.info("Before retrieve orders data");
        Iterable<OrderEntity> orderList = orderService.getOrdersByUserId(userId);

        List<ResponseOrder> result = new ArrayList<>();
        orderList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseOrder.class));
        });

        System.out.println("--->result>"+result);
        
//        try {
//            Thread.sleep(1000);
//            throw new Exception("장애 발생");
//        } catch(InterruptedException ex) {
//            log.warn(ex.getMessage());
//        }

        log.info("Add retrieved orders data");

        return ResponseEntity.status(HttpStatus.OK).body(result);
    }
}
