package com.example.catalogservice.messagequeue;

import com.example.catalogservice.jpa.CatalogEntity;
import com.example.catalogservice.jpa.CatalogRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class KafkaConsumer {
	// 여기서 생산자에서 생산한 카탈로그에 대한 갯수를 수정해야 되어서 repository를 선언한다.
    CatalogRepository repository;

    @Autowired
    public KafkaConsumer(CatalogRepository repository) {
        this.repository = repository;
    }
    
    // 생산자에서 생산한 이벤트 대기한다.
    @KafkaListener(topics = "example-catalog-topic")
    public void updateQty(String kafkaMessage) throws Exception {
    	log.info("\n----------->example-catalog-topic>"+kafkaMessage);

        Map<Object, Object> map = new HashMap<>();
        ObjectMapper mapper = new ObjectMapper();
        
        try {
        	// 생산자에서 발생한 메시지는 OrderDTO이다. 이것을 JSON KEY-VALUE값으로 변환한다.
            map = mapper.readValue(kafkaMessage, new TypeReference<Map<Object, Object>>() {});
        } catch (JsonProcessingException ex) {
            ex.printStackTrace();
        }

        // 생산품의 ID를 확인한다.
        CatalogEntity entity = repository.findByProductId((String)map.get("productId"));
        if (entity != null) {
        	// 수량을 감소시킨다.
            entity.setStock(entity.getStock() - (Integer)map.get("qty"));
            // 데이타베이스에 저장한다.
            repository.save(entity);
        }
        else {
        	log.error("CatalogEntity 상품이 존재하지 않습니다.");
        	throw new Exception("CatalogEntity 상품이 존재하지 않습니다.");
        }
    }
    
    @KafkaListener(topics="example-order-topic")
    public void processMessage(String kafkaMessage) throws Exception {
    	log.info("\n----------->example-order-topic>"+kafkaMessage);
        

        Map<Object, Object> map = new HashMap<>();
        ObjectMapper mapper = new ObjectMapper();
        try {
            map = mapper.readValue(kafkaMessage, new TypeReference<Map<Object, Object>>() {});
        } catch (JsonProcessingException ex) {
            ex.printStackTrace();
        }

        // map에는 order서비스에서 발생시킨 데이타가 존재한다.
        // OrderDto의 내용이 전달되어 온다.
        CatalogEntity entity = repository.findByProductId((String)map.get("productId"));
        if (entity != null) {
            entity.setStock(entity.getStock() - (Integer)map.get("qty"));
            repository.save(entity);
        }
        else {
        	log.error("CatalogEntity 상품이 존재하지 않습니다.");
        	throw new Exception("CatalogEntity 상품이 존재하지 않습니다.");
        }
    	
    }
}
