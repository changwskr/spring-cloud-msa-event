insert into catalog(productId, productName, stock, unitPrice) values('CATALOG-001', 'Berlin', 100, 1500);
insert into catalog(productId, productName, stock, unitPrice) values('CATALOG-002', 'Tokyo', 110, 1000);
insert into catalog(productId, productName, stock, unitPrice) values('CATALOG-003', 'Stockholm', 120, 2000);