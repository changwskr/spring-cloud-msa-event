package com.example.apigatewayservice.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/*
 * configuration, bean은 application.yml 파일을 대처하니 필요시 다시 설정한다.
 */
//@Configuration
public class FilterConfig {
//    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
    	/*
    	 *  이 동작들은 application.yml 파일에서 했던 동작들을 기술한것이다.
    	 */
        return builder.routes()
                .route(r -> r.path("/first-service/**")
                            .filters(f -> f.addRequestHeader("first-request", "first-request-header")
                                                  .addResponseHeader("first-response", "first-response-header"))
                            .uri("http://localhost:8081"))
                .route(r -> r.path("/second-service/**")
                        .filters(f -> f.addRequestHeader("second-request", "second-request-header")
                                              .addResponseHeader("second-response", "second-response-header"))
                        .uri("http://localhost:8082"))
                .route(r -> r.path("/third-service/**")
                        .filters(f -> f.addRequestHeader("third-request", "third-request-header")
                                              .addResponseHeader("third-response", "third-response-header"))
                        .uri("http://localhost:8083"))                
                .build();
    }
}
